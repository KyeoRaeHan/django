from django.apps import AppConfig


class CodecollectConfig(AppConfig):
    name = 'codecollect'
