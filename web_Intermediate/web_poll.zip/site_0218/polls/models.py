from django.db import models
from django.utils import timezone
import datetime
#5. polls app의 models.py 수정하여 DB tables 만들기
# Create your models here.

class Question (models.Model): # DB Table for 설문조사 주제
    question_text = models.CharField(max_length=200) # 설문조사 주제 텍스트
    pub_date = models. DateTimeField('date published') # ‘date published’ : 관리자 페이지에서 보여질 항목명

class Choice (models.Model): # DB Table for 설문조사 주제별 선택지 (+ 선택지마다의 득표 수
# 자동으로 Question table 의 Primary key 를 Foreign Key 로 세팅
# on_delete=models.CASCADE : 질문 ) 항목 삭제 시 관계 된 선택지들도 모두 자동 삭제
    question = models.ForeignKey( Question , on_delete=models.CASCADE) # 설문조사 주제의 id 값
    choice_text = models.CharField(max_length=200) # 설문조사 주제에 대한 선택지 텍스트
    votes = models.IntegerField(default=0) # 해당 선택지의 득표 수
