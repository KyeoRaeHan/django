from django.shortcuts import render
from django.http import HttpResponse
from .models import Question


# 내부 계산 & 데이터 처리 로직
def index(request):
    return HttpResponse('test1, test2, test3')
#
def detail(request,question_id):
    return HttpResponse("You're looking at question {}.".format(question_id))
#
def results(request,question_id):
    response = "You're looking at the results of question {}."
    return HttpResponse(response.format(question_id))

def vote(request,question_id):
    return HttpResponse("You're voting on question {}.".format(question_id))

def index(request):
# order_ pub_date')[:5] : 등록 날짜 기준 내림차순 정렬 후 앞에서 5 개까지만
    latest_question_list = Question.objects.order_by('-pub_date')[:5]
# 지난 실습에서 render() 함수의 {~:~} 로 html 파일에게 넘겨주던 dict 를 context 라고 부릅니다
    context = {'latest_question_list': latest_question_list}
    return render(request, 'polls/index.html', context)
